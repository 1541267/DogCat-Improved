var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "39798",
        "ok": "39798",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23419",
        "ok": "23419",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9564",
        "ok": "9564",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5607",
        "ok": "5607",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10137",
        "ok": "10137",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14043",
        "ok": "14040",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18272",
        "ok": "18273",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20213",
        "ok": "20225",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2904,
    "percentage": 7.2968490878938645
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 867,
    "percentage": 2.1785014322327756
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 36027,
    "percentage": 90.52464947987336
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "113.06",
        "ok": "113.06",
        "ko": "-"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7442",
        "ok": "7442",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23419",
        "ok": "23419",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9834",
        "ok": "9834",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5821",
        "ok": "5821",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9950",
        "ok": "9943",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14521",
        "ok": "14519",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19706",
        "ok": "19717",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21336",
        "ok": "21318",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 435,
    "percentage": 5.845202902445579
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 173,
    "percentage": 2.324643912926633
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6834,
    "percentage": 91.83015318462779
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "21.14",
        "ok": "21.14",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4946",
        "ok": "4946",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21390",
        "ok": "21390",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8813",
        "ok": "8813",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5667",
        "ok": "5667",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9299",
        "ok": "9299",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13576",
        "ok": "13576",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18119",
        "ok": "18119",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19717",
        "ok": "19717",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 480,
    "percentage": 9.704811969268096
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 131,
    "percentage": 2.648604933279418
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4335,
    "percentage": 87.64658309745249
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.05",
        "ok": "14.05",
        "ko": "-"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21374",
        "ok": "21374",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8555",
        "ok": "8555",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5684",
        "ok": "5684",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8410",
        "ok": "8410",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13371",
        "ok": "13371",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18128",
        "ok": "18128",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19772",
        "ok": "19772",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 261,
    "percentage": 10.45673076923077
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 49,
    "percentage": 1.9631410256410255
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2186,
    "percentage": 87.5801282051282
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4946",
        "ok": "4946",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21232",
        "ok": "21232",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9765",
        "ok": "9765",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5830",
        "ok": "5830",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10452",
        "ok": "10462",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14611",
        "ok": "14621",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18616",
        "ok": "18615",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20060",
        "ok": "20059",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 446,
    "percentage": 9.017387788111606
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 87,
    "percentage": 1.7589971694298423
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4413,
    "percentage": 89.22361504245855
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.05",
        "ok": "14.05",
        "ko": "-"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18618",
        "ok": "18618",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8259",
        "ok": "8259",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5414",
        "ok": "5414",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8850",
        "ok": "8864",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12642",
        "ok": "12640",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17262",
        "ok": "17324",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18283",
        "ok": "18306",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 325,
    "percentage": 13.020833333333334
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 73,
    "percentage": 2.9246794871794872
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2098,
    "percentage": 84.05448717948718
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21221",
        "ok": "21221",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10047",
        "ok": "10047",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5604",
        "ok": "5604",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10841",
        "ok": "10841",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14734",
        "ok": "14734",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18367",
        "ok": "18368",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20095",
        "ok": "20130",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 194,
    "percentage": 7.772435897435898
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 26,
    "percentage": 1.0416666666666665
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2276,
    "percentage": 91.18589743589743
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20428",
        "ok": "20428",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9277",
        "ok": "9277",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5401",
        "ok": "5401",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10515",
        "ok": "10515",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13521",
        "ok": "13526",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17085",
        "ok": "17078",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19126",
        "ok": "19126",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 196,
    "percentage": 7.852564102564102
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 32,
    "percentage": 1.282051282051282
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2268,
    "percentage": 90.86538461538461
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "411",
        "ok": "411",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19585",
        "ok": "19585",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10185",
        "ok": "10185",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4914",
        "ok": "4914",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11225",
        "ok": "11225",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13822",
        "ok": "13822",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17773",
        "ok": "17773",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19224",
        "ok": "19224",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 24,
    "percentage": 0.9615384615384616
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 88,
    "percentage": 3.5256410256410255
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2384,
    "percentage": 95.51282051282051
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20983",
        "ok": "20983",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10680",
        "ok": "10680",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5323",
        "ok": "5323",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12284",
        "ok": "12284",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14709",
        "ok": "14709",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18008",
        "ok": "18008",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19546",
        "ok": "19546",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 130,
    "percentage": 5.208333333333334
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 23,
    "percentage": 0.921474358974359
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2343,
    "percentage": 93.8701923076923
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "626",
        "ok": "626",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21527",
        "ok": "21527",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10722",
        "ok": "10722",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5014",
        "ok": "5014",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11755",
        "ok": "11755",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14564",
        "ok": "14564",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18271",
        "ok": "18271",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20227",
        "ok": "20227",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0.3205128205128205
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 51,
    "percentage": 2.043269230769231
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2437,
    "percentage": 97.63621794871796
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21779",
        "ok": "21779",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10013",
        "ok": "10013",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5608",
        "ok": "5608",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10674",
        "ok": "10674",
        "ko": "-"
    },
    "percentiles2": {
        "total": "14707",
        "ok": "14707",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18429",
        "ok": "18429",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19910",
        "ok": "19910",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 151,
    "percentage": 6.049679487179487
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 45,
    "percentage": 1.8028846153846152
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2300,
    "percentage": 92.1474358974359
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2496",
        "ok": "2496",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21078",
        "ok": "21078",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8618",
        "ok": "8618",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5422",
        "ok": "5422",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8254",
        "ok": "8254",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13416",
        "ok": "13416",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16624",
        "ok": "16624",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19067",
        "ok": "19067",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 254,
    "percentage": 10.176282051282051
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 89,
    "percentage": 3.565705128205128
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2153,
    "percentage": 86.25801282051282
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.09",
        "ok": "7.09",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
