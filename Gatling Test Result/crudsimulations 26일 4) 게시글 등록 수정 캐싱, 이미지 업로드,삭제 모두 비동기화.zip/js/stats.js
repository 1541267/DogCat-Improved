var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "37738",
        "ok": "37738",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15200",
        "ok": "15200",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2103",
        "ok": "2103",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1893",
        "ok": "1893",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1762",
        "ok": "1761",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3161",
        "ok": "3181",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5483",
        "ok": "5462",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7790",
        "ok": "8113",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 11548,
    "percentage": 30.60045577402088
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3123,
    "percentage": 8.27547829773703
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 23067,
    "percentage": 61.12406592824209
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "132.88",
        "ok": "132.88",
        "ko": "-"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7089",
        "ok": "7089",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "72",
        "ok": "72",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7786",
        "ok": "7786",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1979",
        "ok": "1979",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1591",
        "ok": "1591",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1738",
        "ok": "1725",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3103",
        "ok": "3107",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4870",
        "ok": "4858",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6023",
        "ok": "6059",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2233,
    "percentage": 31.499506277331076
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 551,
    "percentage": 7.772605445055721
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4305,
    "percentage": 60.727888277613204
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "24.96",
        "ok": "24.96",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4736",
        "ok": "4736",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7683",
        "ok": "7683",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2172",
        "ok": "2172",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1654",
        "ok": "1654",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1936",
        "ok": "1939",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3410",
        "ok": "3402",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5094",
        "ok": "5061",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6428",
        "ok": "6119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1287,
    "percentage": 27.17483108108108
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 329,
    "percentage": 6.94679054054054
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 3120,
    "percentage": 65.87837837837837
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.68",
        "ok": "16.68",
        "ko": "-"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6154",
        "ok": "6154",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1612",
        "ok": "1612",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1392",
        "ok": "1392",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1311",
        "ok": "1303",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2698",
        "ok": "2698",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4091",
        "ok": "4124",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5018",
        "ok": "5138",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 880,
    "percentage": 37.39906502337442
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 245,
    "percentage": 10.41223969400765
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1228,
    "percentage": 52.188695282617935
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8165",
        "ok": "8165",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1291",
        "ok": "1291",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1282",
        "ok": "1282",
        "ko": "-"
    },
    "percentiles1": {
        "total": "809",
        "ok": "811",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2084",
        "ok": "2086",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3771",
        "ok": "3771",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5408",
        "ok": "5408",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1169,
    "percentage": 49.68125796855078
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 195,
    "percentage": 8.287292817679557
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 989,
    "percentage": 42.031449213769655
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6531",
        "ok": "6531",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1542",
        "ok": "1542",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1355",
        "ok": "1355",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1181",
        "ok": "1184",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2493",
        "ok": "2481",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4168",
        "ok": "4184",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5386",
        "ok": "5238",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 853,
    "percentage": 36.25159371015725
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 344,
    "percentage": 14.619634509137272
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1156,
    "percentage": 49.128771780705485
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4736",
        "ok": "4736",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "32",
        "ok": "32",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7618",
        "ok": "7618",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2663",
        "ok": "2663",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1688",
        "ok": "1688",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2441",
        "ok": "2441",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3833",
        "ok": "3833",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5774",
        "ok": "5774",
        "ko": "-"
    },
    "percentiles4": {
        "total": "6784",
        "ok": "6784",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 716,
    "percentage": 15.118243243243242
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 191,
    "percentage": 4.0329391891891895
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 3829,
    "percentage": 80.84881756756756
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.68",
        "ok": "16.68",
        "ko": "-"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "27",
        "ok": "27",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6058",
        "ok": "6058",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1389",
        "ok": "1389",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1345",
        "ok": "1345",
        "ko": "-"
    },
    "percentiles1": {
        "total": "938",
        "ok": "936",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2337",
        "ok": "2329",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3945",
        "ok": "3956",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5069",
        "ok": "5015",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1089,
    "percentage": 46.28134296642584
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 212,
    "percentage": 9.009774755631108
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1052,
    "percentage": 44.708882277943054
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "406",
        "ok": "406",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15200",
        "ok": "15200",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5006",
        "ok": "5006",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3184",
        "ok": "3184",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4465",
        "ok": "4465",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6936",
        "ok": "6936",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11399",
        "ok": "11399",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13776",
        "ok": "13776",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 64,
    "percentage": 2.7199320016999575
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 144,
    "percentage": 6.119847003824904
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2145,
    "percentage": 91.16022099447514
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6671",
        "ok": "6671",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1588",
        "ok": "1588",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1428",
        "ok": "1428",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1170",
        "ok": "1165",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2690",
        "ok": "2676",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4192",
        "ok": "4192",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5223",
        "ok": "5199",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 912,
    "percentage": 38.75903102422439
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 281,
    "percentage": 11.942201444963876
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1160,
    "percentage": 49.29876753081173
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5939",
        "ok": "5939",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1281",
        "ok": "1281",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1251",
        "ok": "1251",
        "ko": "-"
    },
    "percentiles1": {
        "total": "903",
        "ok": "903",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2101",
        "ok": "2100",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3755",
        "ok": "3755",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4836",
        "ok": "4836",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1105,
    "percentage": 46.96132596685083
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 235,
    "percentage": 9.987250318742031
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1013,
    "percentage": 43.051423714407136
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8271",
        "ok": "8271",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2749",
        "ok": "2749",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1810",
        "ok": "1810",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2556",
        "ok": "2556",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3773",
        "ok": "3773",
        "ko": "-"
    },
    "percentiles3": {
        "total": "6228",
        "ok": "6228",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7572",
        "ok": "7572",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 327,
    "percentage": 13.89715257118572
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 121,
    "percentage": 5.1423714407139824
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1905,
    "percentage": 80.9604759881003
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2353",
        "ok": "2353",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6781",
        "ok": "6781",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1570",
        "ok": "1570",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1374",
        "ok": "1374",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1178",
        "ok": "1179",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2576",
        "ok": "2576",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4134",
        "ok": "4134",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5407",
        "ok": "5401",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 913,
    "percentage": 38.80152996175096
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 275,
    "percentage": 11.687207819804504
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1165,
    "percentage": 49.51126221844454
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.29",
        "ok": "8.29",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
