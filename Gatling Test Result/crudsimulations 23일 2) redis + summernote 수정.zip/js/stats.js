var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "38119",
        "ok": "38119",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23406",
        "ok": "23406",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8276",
        "ok": "8276",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4971",
        "ok": "4971",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8325",
        "ok": "8325",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12328",
        "ok": "12314",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16348",
        "ok": "16337",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17912",
        "ok": "18033",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2263,
    "percentage": 5.936672000839476
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 615,
    "percentage": 1.6133686612975158
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 35241,
    "percentage": 92.449959337863
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "112.78",
        "ok": "112.78",
        "ko": "-"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7069",
        "ok": "7069",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23406",
        "ok": "23406",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8618",
        "ok": "8618",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5039",
        "ok": "5039",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8330",
        "ok": "8333",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12582",
        "ok": "12574",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17262",
        "ok": "17271",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18946",
        "ok": "18839",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 383,
    "percentage": 5.418022351110483
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 31,
    "percentage": 0.43853444617343335
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6655,
    "percentage": 94.14344320271609
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.91",
        "ok": "20.91",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4653",
        "ok": "4653",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19929",
        "ok": "19929",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7490",
        "ok": "7490",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5055",
        "ok": "5055",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6942",
        "ok": "6948",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11956",
        "ok": "11958",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16118",
        "ok": "16169",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17448",
        "ok": "17389",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 347,
    "percentage": 7.457554266064904
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 124,
    "percentage": 2.6649473457984096
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4182,
    "percentage": 89.87749838813669
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.77",
        "ok": "13.77",
        "ko": "-"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19554",
        "ok": "19554",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7518",
        "ok": "7518",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5038",
        "ok": "5038",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7027",
        "ok": "7046",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11777",
        "ok": "11789",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16074",
        "ok": "16093",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17398",
        "ok": "17429",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 194,
    "percentage": 8.02980132450331
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 44,
    "percentage": 1.8211920529801324
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2178,
    "percentage": 90.14900662251655
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4653",
        "ok": "4653",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19993",
        "ok": "19993",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8377",
        "ok": "8377",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5138",
        "ok": "5138",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8637",
        "ok": "8629",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12593",
        "ok": "12593",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16481",
        "ok": "16436",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17607",
        "ok": "17653",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 301,
    "percentage": 6.468944766817107
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 94,
    "percentage": 2.0202020202020203
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4258,
    "percentage": 91.51085321298086
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.77",
        "ok": "13.77",
        "ko": "-"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16158",
        "ok": "16158",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7018",
        "ok": "7018",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4796",
        "ok": "4796",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7302",
        "ok": "7312",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10947",
        "ok": "10947",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14624",
        "ok": "14677",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15839",
        "ok": "15861",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 318,
    "percentage": 13.16225165562914
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 73,
    "percentage": 3.0215231788079473
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2025,
    "percentage": 83.81622516556291
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19007",
        "ok": "19007",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8890",
        "ok": "8890",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5057",
        "ok": "5057",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9053",
        "ok": "9056",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12847",
        "ok": "12852",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16626",
        "ok": "16629",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17892",
        "ok": "17892",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 139,
    "percentage": 5.753311258278146
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 35,
    "percentage": 1.4486754966887416
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2242,
    "percentage": 92.79801324503312
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18074",
        "ok": "18074",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8083",
        "ok": "8083",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4922",
        "ok": "4922",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8723",
        "ok": "8723",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12230",
        "ok": "12230",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15602",
        "ok": "15602",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16936",
        "ok": "16936",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 140,
    "percentage": 5.7947019867549665
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 53,
    "percentage": 2.1937086092715234
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2223,
    "percentage": 92.01158940397352
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "504",
        "ok": "504",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17509",
        "ok": "17509",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8762",
        "ok": "8762",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4384",
        "ok": "4384",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8999",
        "ok": "8999",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12010",
        "ok": "12010",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15533",
        "ok": "15533",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16857",
        "ok": "16857",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16,
    "percentage": 0.6622516556291391
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 41,
    "percentage": 1.6970198675496688
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2359,
    "percentage": 97.6407284768212
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19258",
        "ok": "19258",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9252",
        "ok": "9252",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4695",
        "ok": "4695",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9966",
        "ok": "9966",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12967",
        "ok": "12967",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16283",
        "ok": "16283",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17777",
        "ok": "17777",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 67,
    "percentage": 2.7731788079470197
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 28,
    "percentage": 1.1589403973509933
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2321,
    "percentage": 96.06788079470199
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "636",
        "ok": "636",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19900",
        "ok": "19900",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9316",
        "ok": "9316",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4569",
        "ok": "4569",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9844",
        "ok": "9844",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12976",
        "ok": "12976",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16588",
        "ok": "16588",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18009",
        "ok": "18009",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 11,
    "percentage": 0.4552980132450331
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 18,
    "percentage": 0.7450331125827815
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2387,
    "percentage": 98.79966887417218
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "9",
        "ok": "9",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19478",
        "ok": "19478",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8540",
        "ok": "8540",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4956",
        "ok": "4956",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8685",
        "ok": "8685",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12639",
        "ok": "12639",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16469",
        "ok": "16469",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17729",
        "ok": "17729",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 111,
    "percentage": 4.594370860927152
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 37,
    "percentage": 1.531456953642384
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2268,
    "percentage": 93.87417218543047
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2416",
        "ok": "2416",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19283",
        "ok": "19283",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7417",
        "ok": "7417",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4847",
        "ok": "4847",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6442",
        "ok": "6442",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11763",
        "ok": "11763",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15187",
        "ok": "15187",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17376",
        "ok": "17376",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 236,
    "percentage": 9.7682119205298
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 37,
    "percentage": 1.531456953642384
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2143,
    "percentage": 88.70033112582782
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.15",
        "ok": "7.15",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
