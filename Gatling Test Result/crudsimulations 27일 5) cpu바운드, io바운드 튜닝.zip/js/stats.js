var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "38586",
        "ok": "38586",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9248",
        "ok": "9248",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "534",
        "ok": "534",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "775",
        "ok": "775",
        "ko": "-"
    },
    "percentiles1": {
        "total": "236",
        "ok": "236",
        "ko": "-"
    },
    "percentiles2": {
        "total": "680",
        "ok": "678",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1947",
        "ok": "1957",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3642",
        "ok": "3665",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 30489,
    "percentage": 79.01570517804385
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3191,
    "percentage": 8.2698388016379
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4906,
    "percentage": 12.714456020318249
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "140.82",
        "ok": "140.82",
        "ko": "-"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7304",
        "ok": "7304",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4011",
        "ok": "4011",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "percentiles1": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles2": {
        "total": "469",
        "ok": "470",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1429",
        "ok": "1440",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2278",
        "ok": "2280",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 6362,
    "percentage": 87.10295728368017
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 439,
    "percentage": 6.010405257393209
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 503,
    "percentage": 6.886637458926616
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "26.66",
        "ok": "26.66",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4922",
        "ok": "4922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2543",
        "ok": "2543",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "340",
        "ok": "340",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles1": {
        "total": "233",
        "ok": "233",
        "ko": "-"
    },
    "percentiles2": {
        "total": "460",
        "ok": "461",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1018",
        "ok": "1019",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1455",
        "ok": "1447",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 4433,
    "percentage": 90.06501422186103
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 358,
    "percentage": 7.273466070702966
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 131,
    "percentage": 2.6615197074360015
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.96",
        "ok": "17.96",
        "ko": "-"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1989",
        "ok": "1989",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "253",
        "ok": "253",
        "ko": "-"
    },
    "percentiles1": {
        "total": "106",
        "ok": "105",
        "ko": "-"
    },
    "percentiles2": {
        "total": "268",
        "ok": "269",
        "ko": "-"
    },
    "percentiles3": {
        "total": "719",
        "ok": "723",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1290",
        "ok": "1213",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2298,
    "percentage": 96.4735516372796
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 54,
    "percentage": 2.2670025188916876
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 30,
    "percentage": 1.2594458438287155
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1708",
        "ok": "1708",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "percentiles1": {
        "total": "124",
        "ok": "124",
        "ko": "-"
    },
    "percentiles2": {
        "total": "251",
        "ok": "249",
        "ko": "-"
    },
    "percentiles3": {
        "total": "618",
        "ok": "610",
        "ko": "-"
    },
    "percentiles4": {
        "total": "993",
        "ok": "995",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2332,
    "percentage": 97.9009235936188
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 43,
    "percentage": 1.8052057094878253
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7,
    "percentage": 0.2938706968933669
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2151",
        "ok": "2151",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "212",
        "ok": "212",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "percentiles1": {
        "total": "112",
        "ok": "112",
        "ko": "-"
    },
    "percentiles2": {
        "total": "278",
        "ok": "279",
        "ko": "-"
    },
    "percentiles3": {
        "total": "770",
        "ok": "772",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1202",
        "ok": "1210",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2279,
    "percentage": 95.67590260285475
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 73,
    "percentage": 3.0646515533165406
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 30,
    "percentage": 1.2594458438287155
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4922",
        "ok": "4922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4440",
        "ok": "4440",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "955",
        "ok": "955",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "663",
        "ok": "663",
        "ko": "-"
    },
    "percentiles1": {
        "total": "869",
        "ok": "870",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1439",
        "ok": "1438",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2101",
        "ok": "2104",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2661",
        "ok": "2657",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2279,
    "percentage": 46.3023161316538
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 961,
    "percentage": 19.524583502641203
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1682,
    "percentage": 34.173100365705
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.96",
        "ok": "17.96",
        "ko": "-"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2257",
        "ok": "2257",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "172",
        "ok": "172",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "percentiles1": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "percentiles2": {
        "total": "179",
        "ok": "179",
        "ko": "-"
    },
    "percentiles3": {
        "total": "796",
        "ok": "750",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1166",
        "ok": "1021",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2297,
    "percentage": 96.43157010915198
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 57,
    "percentage": 2.392947103274559
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 28,
    "percentage": 1.1754827875734677
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9248",
        "ok": "9248",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2189",
        "ok": "2189",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1639",
        "ok": "1639",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1578",
        "ok": "1578",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3058",
        "ok": "3058",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5590",
        "ok": "5590",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7661",
        "ok": "7661",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 377,
    "percentage": 15.827036104114189
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 482,
    "percentage": 20.23509655751469
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1523,
    "percentage": 63.93786733837111
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2015",
        "ok": "2015",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "214",
        "ok": "214",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "257",
        "ok": "257",
        "ko": "-"
    },
    "percentiles1": {
        "total": "117",
        "ok": "117",
        "ko": "-"
    },
    "percentiles2": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "percentiles3": {
        "total": "742",
        "ok": "741",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1252",
        "ok": "1184",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2281,
    "percentage": 95.75986565910999
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 78,
    "percentage": 3.27455919395466
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 23,
    "percentage": 0.9655751469353484
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2667",
        "ok": "2667",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "312",
        "ok": "312",
        "ko": "-"
    },
    "percentiles1": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles2": {
        "total": "245",
        "ok": "246",
        "ko": "-"
    },
    "percentiles3": {
        "total": "902",
        "ok": "906",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1577",
        "ok": "1584",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2232,
    "percentage": 93.70277078085643
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 98,
    "percentage": 4.114189756507137
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 52,
    "percentage": 2.18303946263644
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4461",
        "ok": "4461",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "971",
        "ok": "971",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "833",
        "ok": "833",
        "ko": "-"
    },
    "percentiles1": {
        "total": "801",
        "ok": "801",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1558",
        "ok": "1558",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2473",
        "ok": "2473",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3316",
        "ok": "3327",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1189,
    "percentage": 49.91603694374475
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 364,
    "percentage": 15.28127623845508
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 829,
    "percentage": 34.802686817800165
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2382",
        "ok": "2382",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2668",
        "ok": "2668",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "329",
        "ok": "329",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "343",
        "ok": "343",
        "ko": "-"
    },
    "percentiles1": {
        "total": "200",
        "ok": "200",
        "ko": "-"
    },
    "percentiles2": {
        "total": "463",
        "ok": "463",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1074",
        "ok": "1070",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1536",
        "ok": "1534",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2130,
    "percentage": 89.4206549118388
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 184,
    "percentage": 7.724601175482787
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 68,
    "percentage": 2.8547439126784218
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "8.69",
        "ok": "8.69",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
