var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "38343",
        "ok": "38312",
        "ko": "31"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "4",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "40996",
        "ok": "40996",
        "ko": "20144"
    },
    "meanResponseTime": {
        "total": "8981",
        "ok": "8983",
        "ko": "6080"
    },
    "standardDeviation": {
        "total": "5995",
        "ok": "5994",
        "ko": "5928"
    },
    "percentiles1": {
        "total": "9452",
        "ok": "9412",
        "ko": "3651"
    },
    "percentiles2": {
        "total": "13028",
        "ok": "13050",
        "ko": "11030"
    },
    "percentiles3": {
        "total": "18665",
        "ok": "18768",
        "ko": "16719"
    },
    "percentiles4": {
        "total": "25537",
        "ok": "26071",
        "ko": "20144"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3616,
    "percentage": 9.430665310486921
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 864,
    "percentage": 2.253344808700415
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 33832,
    "percentage": 88.23514070364864
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.0808491771640195
},
    "meanNumberOfRequestsPerSecond": {
        "total": "105.63",
        "ok": "105.54",
        "ko": "0.09"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7131",
        "ok": "7131",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22079",
        "ok": "22079",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8239",
        "ok": "8239",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5078",
        "ok": "5078",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9077",
        "ok": "9073",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11798",
        "ok": "11804",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16141",
        "ok": "16125",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18757",
        "ok": "18891",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 550,
    "percentage": 7.7128032534006445
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 121,
    "percentage": 1.696816715748142
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6460,
    "percentage": 90.59038003085121
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.64",
        "ok": "19.64",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4719",
        "ok": "4714",
        "ko": "5"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "992"
    },
    "maxResponseTime": {
        "total": "22086",
        "ok": "22086",
        "ko": "13945"
    },
    "meanResponseTime": {
        "total": "7534",
        "ok": "7535",
        "ko": "6319"
    },
    "standardDeviation": {
        "total": "5085",
        "ok": "5085",
        "ko": "5278"
    },
    "percentiles1": {
        "total": "8516",
        "ok": "8510",
        "ko": "4546"
    },
    "percentiles2": {
        "total": "11321",
        "ok": "11283",
        "ko": "11030"
    },
    "percentiles3": {
        "total": "14927",
        "ok": "14926",
        "ko": "13945"
    },
    "percentiles4": {
        "total": "15787",
        "ok": "15654",
        "ko": "13945"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 565,
    "percentage": 11.972875609239246
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 154,
    "percentage": 3.263403263403263
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 3995,
    "percentage": 84.65776647594829
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 5,
    "percentage": 0.10595465140919687
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13",
        "ok": "12.99",
        "ko": "0.01"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "3342"
    },
    "maxResponseTime": {
        "total": "22337",
        "ok": "22337",
        "ko": "16719"
    },
    "meanResponseTime": {
        "total": "7472",
        "ok": "7472",
        "ko": "7904"
    },
    "standardDeviation": {
        "total": "5016",
        "ok": "5014",
        "ko": "6234"
    },
    "percentiles1": {
        "total": "8443",
        "ok": "8455",
        "ko": "3651"
    },
    "percentiles2": {
        "total": "11176",
        "ok": "11183",
        "ko": "16719"
    },
    "percentiles3": {
        "total": "14821",
        "ok": "14852",
        "ko": "16719"
    },
    "percentiles4": {
        "total": "15574",
        "ok": "15551",
        "ko": "16719"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 294,
    "percentage": 12.148760330578511
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 74,
    "percentage": 3.0578512396694215
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2049,
    "percentage": 84.6694214876033
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4719",
        "ok": "4714",
        "ko": "5"
    },
    "minResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "1233"
    },
    "maxResponseTime": {
        "total": "22349",
        "ok": "22349",
        "ko": "14043"
    },
    "meanResponseTime": {
        "total": "7995",
        "ok": "7996",
        "ko": "7063"
    },
    "standardDeviation": {
        "total": "5100",
        "ok": "5100",
        "ko": "5009"
    },
    "percentiles1": {
        "total": "9122",
        "ok": "9129",
        "ko": "8285"
    },
    "percentiles2": {
        "total": "11883",
        "ok": "11864",
        "ko": "10259"
    },
    "percentiles3": {
        "total": "15106",
        "ok": "15108",
        "ko": "14043"
    },
    "percentiles4": {
        "total": "16683",
        "ok": "16543",
        "ko": "14043"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 506,
    "percentage": 10.722610722610723
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 133,
    "percentage": 2.818393727484637
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4075,
    "percentage": 86.35304089849545
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 5,
    "percentage": 0.10595465140919687
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13",
        "ok": "12.99",
        "ko": "0.01"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "1436"
    },
    "maxResponseTime": {
        "total": "31839",
        "ok": "31839",
        "ko": "13291"
    },
    "meanResponseTime": {
        "total": "8724",
        "ok": "8728",
        "ko": "5410"
    },
    "standardDeviation": {
        "total": "5638",
        "ok": "5637",
        "ko": "5573"
    },
    "percentiles1": {
        "total": "9251",
        "ok": "9254",
        "ko": "1502"
    },
    "percentiles2": {
        "total": "13190",
        "ok": "13191",
        "ko": "13291"
    },
    "percentiles3": {
        "total": "17558",
        "ok": "17503",
        "ko": "13291"
    },
    "percentiles4": {
        "total": "22514",
        "ok": "22459",
        "ko": "13291"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 279,
    "percentage": 11.52892561983471
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 48,
    "percentage": 1.9834710743801653
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2090,
    "percentage": 86.36363636363636
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "1137"
    },
    "maxResponseTime": {
        "total": "20643",
        "ok": "20643",
        "ko": "11818"
    },
    "meanResponseTime": {
        "total": "8198",
        "ok": "8203",
        "ko": "4699"
    },
    "standardDeviation": {
        "total": "4890",
        "ok": "4888",
        "ko": "5034"
    },
    "percentiles1": {
        "total": "9397",
        "ok": "9413",
        "ko": "1141"
    },
    "percentiles2": {
        "total": "11814",
        "ok": "11793",
        "ko": "11818"
    },
    "percentiles3": {
        "total": "14818",
        "ok": "14815",
        "ko": "11818"
    },
    "percentiles4": {
        "total": "16179",
        "ok": "16243",
        "ko": "11818"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 230,
    "percentage": 9.50413223140496
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 61,
    "percentage": 2.520661157024793
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2126,
    "percentage": 87.85123966942149
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "53",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "28707",
        "ok": "28707",
        "ko": "4996"
    },
    "meanResponseTime": {
        "total": "9728",
        "ok": "9738",
        "ko": "1666"
    },
    "standardDeviation": {
        "total": "5711",
        "ok": "5706",
        "ko": "2354"
    },
    "percentiles1": {
        "total": "10335",
        "ok": "10343",
        "ko": "2"
    },
    "percentiles2": {
        "total": "14093",
        "ok": "14097",
        "ko": "4996"
    },
    "percentiles3": {
        "total": "18826",
        "ok": "18831",
        "ko": "4996"
    },
    "percentiles4": {
        "total": "22997",
        "ok": "22999",
        "ko": "4996"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 200,
    "percentage": 8.264462809917356
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 39,
    "percentage": 1.6115702479338843
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2178,
    "percentage": 90.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "562",
        "ok": "562",
        "ko": "8058"
    },
    "maxResponseTime": {
        "total": "40996",
        "ok": "40996",
        "ko": "20144"
    },
    "meanResponseTime": {
        "total": "16011",
        "ok": "16016",
        "ko": "12173"
    },
    "standardDeviation": {
        "total": "7143",
        "ok": "7143",
        "ko": "5638"
    },
    "percentiles1": {
        "total": "16292",
        "ok": "16295",
        "ko": "8316"
    },
    "percentiles2": {
        "total": "20630",
        "ok": "20637",
        "ko": "20144"
    },
    "percentiles3": {
        "total": "27835",
        "ok": "27840",
        "ko": "20144"
    },
    "percentiles4": {
        "total": "32831",
        "ok": "32835",
        "ko": "20144"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.5785123966942148
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 14,
    "percentage": 0.5785123966942148
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2389,
    "percentage": 98.71900826446281
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2417",
        "ok": "2417",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21808",
        "ok": "21808",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8082",
        "ok": "8082",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4677",
        "ok": "4677",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9000",
        "ok": "9001",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11351",
        "ok": "11351",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14944",
        "ok": "14935",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16119",
        "ok": "16354",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 157,
    "percentage": 6.495655771617708
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 63,
    "percentage": 2.6065370293752586
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2197,
    "percentage": 90.89780719900703
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.66",
        "ok": "6.66",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "321",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "40585",
        "ok": "40585",
        "ko": "1851"
    },
    "meanResponseTime": {
        "total": "15445",
        "ok": "15464",
        "ko": "621"
    },
    "standardDeviation": {
        "total": "6657",
        "ok": "6640",
        "ko": "870"
    },
    "percentiles1": {
        "total": "15615",
        "ok": "15629",
        "ko": "10"
    },
    "percentiles2": {
        "total": "19724",
        "ok": "19731",
        "ko": "1851"
    },
    "percentiles3": {
        "total": "26727",
        "ok": "26732",
        "ko": "1851"
    },
    "percentiles4": {
        "total": "31989",
        "ok": "31993",
        "ko": "1851"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2,
    "percentage": 0.08264462809917356
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 6,
    "percentage": 0.24793388429752067
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2409,
    "percentage": 99.54545454545455
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2420",
        "ok": "2417",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "11"
    },
    "maxResponseTime": {
        "total": "18356",
        "ok": "18356",
        "ko": "16223"
    },
    "meanResponseTime": {
        "total": "6968",
        "ok": "6966",
        "ko": "8054"
    },
    "standardDeviation": {
        "total": "4985",
        "ok": "4983",
        "ko": "6619"
    },
    "percentiles1": {
        "total": "7796",
        "ok": "7783",
        "ko": "7927"
    },
    "percentiles2": {
        "total": "11137",
        "ok": "11136",
        "ko": "16223"
    },
    "percentiles3": {
        "total": "14577",
        "ok": "14569",
        "ko": "16223"
    },
    "percentiles4": {
        "total": "15455",
        "ok": "15437",
        "ko": "16223"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 378,
    "percentage": 15.619834710743802
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 91,
    "percentage": 3.760330578512397
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1948,
    "percentage": 80.49586776859505
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.12396694214876033
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.67",
        "ok": "6.66",
        "ko": "0.01"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2417",
        "ok": "2417",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21748",
        "ok": "21748",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7120",
        "ok": "7120",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5110",
        "ok": "5110",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8131",
        "ok": "8131",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11122",
        "ok": "11122",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14849",
        "ok": "14849",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15936",
        "ok": "15936",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 441,
    "percentage": 18.24575920562681
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 60,
    "percentage": 2.4824162184526273
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1916,
    "percentage": 79.27182457592056
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6.66",
        "ok": "6.66",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
