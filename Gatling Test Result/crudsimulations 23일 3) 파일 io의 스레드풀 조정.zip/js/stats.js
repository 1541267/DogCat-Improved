var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "39029",
        "ok": "39029",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20757",
        "ok": "20757",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7725",
        "ok": "7725",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4827",
        "ok": "4827",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7183",
        "ok": "7189",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11584",
        "ok": "11581",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16133",
        "ok": "16155",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18001",
        "ok": "17964",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2703,
    "percentage": 6.925619411207052
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 772,
    "percentage": 1.978016346819032
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 35554,
    "percentage": 91.09636424197392
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "116.16",
        "ok": "116.16",
        "ko": "-"
    }
},
contents: {
"req_user-login-2088474324": {
        type: "REQUEST",
        name: "User Login",
path: "User Login",
pathFormatted: "req_user-login-2088474324",
stats: {
    "name": "User Login",
    "numberOfRequests": {
        "total": "7321",
        "ok": "7321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20018",
        "ok": "20018",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7542",
        "ok": "7542",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4813",
        "ok": "4813",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6902",
        "ok": "6899",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10528",
        "ok": "10530",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16882",
        "ok": "16885",
        "ko": "-"
    },
    "percentiles4": {
        "total": "17985",
        "ok": "17935",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 473,
    "percentage": 6.460866001912308
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 168,
    "percentage": 2.2947684742521512
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6680,
    "percentage": 91.24436552383554
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "21.79",
        "ok": "21.79",
        "ko": "-"
    }
}
    },"req_listposts-765898165": {
        type: "REQUEST",
        name: "ListPosts",
path: "ListPosts",
pathFormatted: "req_listposts-765898165",
stats: {
    "name": "ListPosts",
    "numberOfRequests": {
        "total": "4883",
        "ok": "4883",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19451",
        "ok": "19451",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6956",
        "ok": "6956",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4748",
        "ok": "4748",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6199",
        "ok": "6206",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10778",
        "ok": "10794",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15759",
        "ok": "15744",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16795",
        "ok": "16813",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 476,
    "percentage": 9.748105672742167
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 114,
    "percentage": 2.3346303501945527
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4293,
    "percentage": 87.91726397706327
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.53",
        "ok": "14.53",
        "ko": "-"
    }
}
    },"req_load-register-p--68640686": {
        type: "REQUEST",
        name: "Load Register Page",
path: "Load Register Page",
pathFormatted: "req_load-register-p--68640686",
stats: {
    "name": "Load Register Page",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17832",
        "ok": "17832",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6955",
        "ok": "6955",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4704",
        "ok": "4704",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6276",
        "ok": "6276",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10918",
        "ok": "10918",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15261",
        "ok": "15261",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16549",
        "ok": "16549",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 229,
    "percentage": 9.392945036915505
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 70,
    "percentage": 2.871205906480722
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2139,
    "percentage": 87.73584905660378
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_getpostdetail-1677102311": {
        type: "REQUEST",
        name: "GetPostDetail",
path: "GetPostDetail",
pathFormatted: "req_getpostdetail-1677102311",
stats: {
    "name": "GetPostDetail",
    "numberOfRequests": {
        "total": "4883",
        "ok": "4883",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "18",
        "ok": "18",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20572",
        "ok": "20572",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9245",
        "ok": "9245",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4972",
        "ok": "4972",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8745",
        "ok": "8750",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13328",
        "ok": "13328",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17760",
        "ok": "17769",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19436",
        "ok": "19440",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 176,
    "percentage": 3.604341593282818
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 36,
    "percentage": 0.7372516895351219
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4671,
    "percentage": 95.65840671718206
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.53",
        "ok": "14.53",
        "ko": "-"
    }
}
    },"req_upload-summerno--1189584709": {
        type: "REQUEST",
        name: "Upload Summernote Image",
path: "Upload Summernote Image",
pathFormatted: "req_upload-summerno--1189584709",
stats: {
    "name": "Upload Summernote Image",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16206",
        "ok": "16206",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6463",
        "ok": "6463",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4538",
        "ok": "4538",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5983",
        "ok": "5985",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10340",
        "ok": "10340",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14768",
        "ok": "14768",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15625",
        "ok": "15625",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 331,
    "percentage": 13.57670221493027
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 72,
    "percentage": 2.9532403609515994
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2035,
    "percentage": 83.47005742411812
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_create-post-wit--1960175101": {
        type: "REQUEST",
        name: "Create Post with Embedded Image",
path: "Create Post with Embedded Image",
pathFormatted: "req_create-post-wit--1960175101",
stats: {
    "name": "Create Post with Embedded Image",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17512",
        "ok": "17512",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7676",
        "ok": "7676",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4758",
        "ok": "4758",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7151",
        "ok": "7136",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11813",
        "ok": "11822",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15595",
        "ok": "15594",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16785",
        "ok": "16782",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 190,
    "percentage": 7.793273174733388
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 59,
    "percentage": 2.4200164068908943
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2189,
    "percentage": 89.78671041837572
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_final-image-upl--423740624": {
        type: "REQUEST",
        name: "Final Image Upload",
path: "Final Image Upload",
pathFormatted: "req_final-image-upl--423740624",
stats: {
    "name": "Final Image Upload",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17814",
        "ok": "17814",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7471",
        "ok": "7471",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4531",
        "ok": "4531",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7334",
        "ok": "7334",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11279",
        "ok": "11278",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14747",
        "ok": "14747",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16433",
        "ok": "16433",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 188,
    "percentage": 7.71123872026251
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 47,
    "percentage": 1.9278096800656275
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2203,
    "percentage": 90.36095159967186
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_upload-edit-ima--560244956": {
        type: "REQUEST",
        name: "Upload Edit Image",
path: "Upload Edit Image",
pathFormatted: "req_upload-edit-ima--560244956",
stats: {
    "name": "Upload Edit Image",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "696",
        "ok": "696",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20757",
        "ok": "20757",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9026",
        "ok": "9026",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4840",
        "ok": "4840",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9011",
        "ok": "9011",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12630",
        "ok": "12630",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16977",
        "ok": "16977",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18471",
        "ok": "18471",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5,
    "percentage": 0.20508613617719443
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 56,
    "percentage": 2.2969647251845777
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2377,
    "percentage": 97.49794913863823
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_modify-post-wit--1174416379": {
        type: "REQUEST",
        name: "Modify Post with Embedded Image",
path: "Modify Post with Embedded Image",
pathFormatted: "req_modify-post-wit--1174416379",
stats: {
    "name": "Modify Post with Embedded Image",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18020",
        "ok": "18020",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7956",
        "ok": "7956",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4467",
        "ok": "4467",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8028",
        "ok": "8028",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11708",
        "ok": "11708",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15323",
        "ok": "15323",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16739",
        "ok": "16739",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 131,
    "percentage": 5.373256767842493
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 44,
    "percentage": 1.8047579983593112
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2263,
    "percentage": 92.8219852337982
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_final-edit-imag--677327214": {
        type: "REQUEST",
        name: "Final Edit Image Upload",
path: "Final Edit Image Upload",
pathFormatted: "req_final-edit-imag--677327214",
stats: {
    "name": "Final Edit Image Upload",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "986",
        "ok": "986",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20437",
        "ok": "20437",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9073",
        "ok": "9073",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4788",
        "ok": "4788",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8575",
        "ok": "8575",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13272",
        "ok": "13272",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16762",
        "ok": "16762",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18472",
        "ok": "18472",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 7,
    "percentage": 0.2871205906480722
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2431,
    "percentage": 99.71287940935193
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_deletepost--537026293": {
        type: "REQUEST",
        name: "DeletePost",
path: "DeletePost",
pathFormatted: "req_deletepost--537026293",
stats: {
    "name": "DeletePost",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "18133",
        "ok": "18133",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7241",
        "ok": "7241",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4702",
        "ok": "4702",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6820",
        "ok": "6820",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11363",
        "ok": "11363",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15196",
        "ok": "15196",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16755",
        "ok": "16755",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 192,
    "percentage": 7.875307629204266
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 55,
    "percentage": 2.2559474979491387
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2191,
    "percentage": 89.86874487284659
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    },"req_deletepost-redi--1488157886": {
        type: "REQUEST",
        name: "DeletePost Redirect 1",
path: "DeletePost Redirect 1",
pathFormatted: "req_deletepost-redi--1488157886",
stats: {
    "name": "DeletePost Redirect 1",
    "numberOfRequests": {
        "total": "2438",
        "ok": "2438",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17872",
        "ok": "17872",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6703",
        "ok": "6703",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4635",
        "ok": "4635",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6004",
        "ok": "6004",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10778",
        "ok": "10778",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14218",
        "ok": "14218",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16477",
        "ok": "16477",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 312,
    "percentage": 12.797374897456931
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 44,
    "percentage": 1.8047579983593112
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2082,
    "percentage": 85.39786710418376
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.26",
        "ok": "7.26",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
